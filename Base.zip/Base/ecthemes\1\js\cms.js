﻿if ($('.ZoneInfo').length > 0 || $('.targetDIV').length === 0) {
    $('#sidebar').css({visibility: 'hidden'});
    // if (window.location.href.indexOf('.aspx') === -1) {
    //     window.location.href = '/cmlogin.aspx?RedirectURL=' + window.location.pathname;
    // }

}
var pathParts = location.pathname.split('/');
if (pathParts[2] == 'regions-html') {
    $('ion-header-bar a.back-button').hide();
} else if (pathParts.length == 4 && pathParts[3] != 'contents-html') {
    $('ion-header-bar a.back-button').attr('href', '/' + ['content', pathParts[2], 'contents-html'].join('/'));
}

/* $('[ng-include]').each(function () {
    var url = $(this).attr('src')
        .replace("'templates", '')
        .replace(".html", '-html')
        .replace(/'/g, '');
    window.location.href = url;
    console.log(url);
}); */

var iOS=!!navigator.platform && /\b(iPad|iPhone|iPod|Android)\b/g.test(navigator.platform);
if(!iOS)
{ 

$('[ng-click]').each(function () {
    var url = $(this).attr('ng-click')
        .replace("updateRegion({section:'", '/content/')
        .replace(/,\s?page:/, '/')
        .replace(", 'language':'english'})", '')
        .replace(", 'language':'french'})", '')
        .replace(", 'language':'spanish'})", '')
        .replace(".html", '-html')
        .replace(/'/g, '');
    this.href = url;
    console.log(url);
});


$('#mobile-content a').each(function () {
    if (this.hash) {
        this.href = this.hash
            .replace('#/contents', '/content')
            .replace('#/content', '/content');
    }
    this.href = this.href.replace('.html', '-html');
});

}


$('ion-modal-view ion-header-bar').addClass('bar').addClass('bar-header');
$("a[href*='openCalculatorMain()']").each(function () {
    $(this).attr('href', '#');
    $(this).click(function () {
        alert('Calculators are not editable');
    });
});

var mobileTitle = $('.title.title-center.header-item').text();
if (mobileTitle) {
    $('.title.title-center.header-item,title').text(mobileTitle.replace('- Pocket Blast Guide', '').replace('/', ''));
}
$.post('https://manage.blastershandbook.com/api/v1/update/info', {'path': location.pathname}, function (result) {
    if (result?.data?.date)
        $('.update-info').text('Updated: ' + result.data.date);
});


$(document).ready(function() {
  // Check if user agent contains "Android"
  if(navigator.userAgent.match(/Android/i)) {
    // Code to run if user is using an Android device
    // For example:
    alert("Welcome Android user!");
  }
});