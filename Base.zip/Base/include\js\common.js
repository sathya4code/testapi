/* start of common.js */
//This file is used in all admin pages, including default.aspx in edit mode
var parentWnd = self.opener;

var pageName = 'default.aspx';
var clickObj = null

function submitForm(form) {
    //get the form element's document to create the input control with
    //(this way will work across windows in IE8)
    var button = form.ownerDocument.createElement('input');
    //make sure it can't be seen/disrupts layout (even momentarily)
    button.style.display = 'none';
    //make it such that it will invoke submit if clicked
    button.type = 'submit';
    //append it and click it
    form.appendChild(button).click();
    //if it was prevented, make sure we don't get a build up of buttons
    form.removeChild(button);
}

function process_form(action) {
    var msg = "";
    var elFormAction = GetElementByClientId("formaction");

    if (elFormAction != null) {
        elFormAction.value = action;
    }
    //GetElementByClientId("formaction").value = action;
    //document.forms[0].ctl00_action.value=action

    if (msg == "") {
        submitForm(document.forms[0]);
        // part of #9055 - use __doPostBack() instead of form.submit() because RAD editor wasn't being saved 
        // document.forms[0].submit();
        // __doPostBack(); // APF 2018.03.22 - Calling submitForm instead
    }
    else
        errors.showError(msg);
}

function encodeMyHtml(strValue) {
    var encodedHtml = strValue;
    encodedHtml = stringreplace(encodedHtml, "=", "%3F");
    encodedHtml = stringreplace(encodedHtml, "+", "%2B");
    encodedHtml = stringreplace(encodedHtml, "?", "%3F");
    encodedHtml = stringreplace(encodedHtml, "&", "%26");
    encodedHtml = stringreplace(encodedHtml, "@", "%40");
    return encodedHtml;
}

function PreviewChanges(ArticleID) {
    window.open(pageName + "?Mode=Preview&ArticleID=" + ArticleID)
}

function PreviewChangesFromWF(ArticleID) {
    window.open('default.aspx?Mode=Preview&ArticleID=' + ArticleID + '&pinwf=1');
}

function FontHelp() {
    window.open('FontHelp.htm', 'Help', 'toolbar=no,width=300,height=450,resizable, scrollbars');
}
function SetAction(action) {
    GetElementByClientId('action').value = action;
    //document.forms[0].formaction.value=action
}

function ResubmitFormWithEdit(ArticleID) {
    location.href = pageName + "?Mode=BusyEditing&ArticleID=" + ArticleID
}
function ResubmitForm(ArticleID) {
    location.href = pageName + "?ArticleID=" + ArticleID;
}

function AddComments(ArticleID, ItemRecordID) {
    var strURL
    strURL = "/Workflow/WorkflowComments.aspx?ArticleID=" + ArticleID + "&ItemRecordId=" + ItemRecordID
    window.open(strURL, 'Comments', 'toolbar=no,width=820,height=600,resizable, scrollbars');
}
function GoToAttributes(ArticleID, ItemRecordID) {
    location.href = "/ArticleAttributeEdit.aspx?Function=Workflow&ArticleID=" + ArticleID + "&ItemRecordId=" + ItemRecordID

}
function ResubmitFormAfterCheckin(ArticleID) {
    location.href = pageName + "?ArticleID=" + ArticleID

}

/*************************************************************************
This code is from Dynamic Web Coding at http://www.dyn-web.com/
See Terms of Use at http://www.dyn-web.com/bus/terms.html
regarding conditions under which you may use this code.
This notice must be retained in the code as is!

This is used when embedding the shopping site inside an iframe.
Use these function to allow the iframe to resize depending on the size
of the shopping page so that scroll bars do not show.
*************************************************************************/

function getDocHeight(doc) {
    var docHt = 0, sh, oh;

    if (doc.body) {
        if (doc.body.scrollHeight) docHt = sh = doc.body.scrollHeight;
        if (doc.body.offsetHeight) docHt = oh = doc.body.offsetHeight;
        if (sh && oh) {
            docHt = Math.max(sh, oh);
        }
        else if (!sh && oh) {
            docHt = oh;
        }
        else if (sh && !oh) {
            docHt = sh;
        }

    }
    return docHt;
}

function getDocWidth(doc) {
    var docWt = 0, sw, ow;

    if (doc.body) {

        if (doc.body.scrollWidth) {
            docWt = sw = doc.body.scrollWidth;

        }
        if (doc.body.offsetWidth) {
            docWt = ow = doc.body.offsetWidth;
        }
        if (sw && ow) {
            docWt = Math.max(sw, ow);
        }

        else if (!sw && ow) {
            docWt = ow
        }
        else if (sw && !ow) {
            docWt = sw;
        }
    }

    return docWt;
}

function ResizeParentFrame(iframeName) {
    var iframeWin = window.frames[iframeName];
    var iframeEl = document.getElementById ? document.getElementById(iframeName) : document.all ? document.all[iframeName] : null;
    if (iframeEl && iframeWin) {

        //iframeEl.style.height = "30px";
        iframeEl.style.height = "auto"; // helps resize (for some) if new doc shorter than previous  

        var docHt = getDocHeight(iframeWin.document);
        var docWt = getDocWidth(iframeWin.document);
        if (docHt) iframeEl.style.height = docHt + "px";
        if (docWt) iframeEl.style.width = docWt + "px";
        //alert("height" + docHt + "px");
    }
}


function loadIframe(iframeName, url) {
    if (window.frames[iframeName]) {
        window.frames[iframeName].location = url;
        return false;
    }
    else return true;
}

function ExecParentWndScript(sScript, close) {

    if (!parentWnd)
        return;

    if (parentWnd.closed)
        return;

    if (parentWnd.execScript) {
        parentWnd.execScript(sScript);
    } else {
        eval('self.opener.' + sScript);
    }

    if (close)
        setTimeout("window.close", 2000);

}

function getSelectedButton(buttonGroup) {
    for (var i = 0; i < buttonGroup.length; i++) {
        if (buttonGroup[i].checked) {
            return i
        }
    }
    return 0
}

function isvalidemail(s) {

    if (s.length > 0) {
        if (s.indexOf("@") != -1 && s.indexOf(".") != -1) {
            //email is valid
            return true;
        }
        else {
            //email is not valid
            return false;
        }
    }
    else {
        //if string is empty just return true as we assume 
        //the field is not mandatory.
        return true;
    }

}

function is_checked(sele) {
    var i;
    var num_of_selection;

    if (!sele)
        return false

    if (sele.length) {
        num_of_selection = sele.length;
        for (i = 0; i < num_of_selection; i++)
            if (sele[i].checked)
                return true;
    }
    else
        return sele.checked
}

function get_checkedID(sele) {
    var i;
    var num_of_selection;

    if (!sele)
        return -1

    if (sele.length) {
        num_of_selection = sele.length;
        for (i = 0; i < num_of_selection; i++)
            if (sele[i].checked)
                return sele[i].value;
    }
    else {
        if (sele.checked)
            return sele.value;
    }
}

function isblank(s) {
    for (var i = 0; i < s.length; i++) {
        var c = s.charAt(i);
        if ((c != ' ') && (c != '\n') && (c != '\t'))
            return false;
    }
    return true;
}

function MoveFieldUpDown(Box, Direction) {

    var k = 0
    var j = 0

    j = Box.options.selectedIndex
    if (j < 0) {
        return
    }

    //don't allow sections to move up or down 
    if (Box.options[j].value == 0) {
        return
    }

    //don't allow an item to move between sections 
    if (Direction == "U") {
        //only check if the item to move up is not currently at the top
        if (j > 0) {
            if (Box.options[j - 1].value == 0) {
                alert("You cannot move a question between sections")
                return
            }
        }
    }
        //only check if the item to move down is not currently at the bottom
    else if (Box.options.length > j + 1) {
        if (Box.options[j + 1].value == 0) {
            alert("You cannot move a question between sections")
            return
        }
    }

    OldValue = Box.options[j].value
    OldText = Box.options[j].text
    OldStyle = Box.options[j].style.cssText;
    if (Direction == "U") {
        if (j == 0) {
            return
        }
        k = j - 1
        nValue = Box.options[k].value
        nText = Box.options[k].text

        Box.options[j] = new Option(nText, nValue)
        Box.options[j].style.cssText = Box.options[k].style.cssText

        Box.options[k].value = OldValue;
        Box.options[k].text = OldText;
        Box.options[k].style.cssText = OldStyle;
        Box.options[k].selected = true
    }

    if (Direction == "D") {
        if (Box.options.length == j + 1) {
            return
        }
        k = j + 1

        nValue = Box.options[k].value
        nText = Box.options[k].text

        Box.options[j] = new Option(nText, nValue)
        Box.options[j].style.cssText = Box.options[k].style.cssText

        Box.options[k].value = OldValue;
        Box.options[k].text = OldText;
        Box.options[k].style.cssText = OldStyle;
        Box.options[k].selected = true

    }


}

function move(fBox, tBox) {
    for (var i = 0; i < fBox.options.length; i++) {
        if (fBox.options[i].selected && fBox.options[i].value != "") {
            var no = new Option();
            no.value = fBox.options[i].value;
            no.text = fBox.options[i].text;
            no.style.cssText = fBox.options[i].style.cssText;
            tBox.options[tBox.options.length] = no;
            fBox.options[i].value = "";
            fBox.options[i].text = "";
        }
    }
    BumpUp(fBox);
}

function moveall(fBox, tBox) {
    for (var i = 0; i < fBox.options.length; i++) {
        var no = new Option();
        no.value = fBox.options[i].value;
        no.text = fBox.options[i].text;
        no.style.cssText = fBox.options[i].style.cssText;
        tBox.options[tBox.options.length] = no;
        fBox.options[i].value = "";
        fBox.options[i].text = "";
    }
    BumpUp(fBox);

}

function remove(fBox) {
    for (var i = 0; i < fBox.options.length; i++) {
        if (fBox.options[i].selected && fBox.options[i].value != "") {
            var no = new Option();
            no.value = fBox.options[i].value;
            no.text = fBox.options[i].text;
            no.style.cssText = fBox.options[i].style.cssText;
            fBox.options[i].value = "";
            fBox.options[i].text = "";
        }
    }
    BumpUp(fBox);
}

function BumpUp(Box) {
    for (var i = 0; i < Box.options.length; i++) {
        if (Box.options[i].value == "") {
            for (var j = i; j < Box.options.length - 1; j++) {
                Box.options[j].value = Box.options[j + 1].value;
                Box.options[j].text = Box.options[j + 1].text;
            }
            var ln = i;
            break;
        }
    }
    if (ln < Box.options.length) {
        Box.options.length -= 1;
        BumpUp(Box);
    }
}

function showHideCombo(mLeft, mTop, mWidth, mHeight, showHide) {


    //show/hide combo only if necessary
    var elm;
    //use the following array to do quick search
    //N.B. pageToSkip is a 2D array
    //each pageToSkip[] has X no. of elements
    //pageToSkip[m][0] = pageName (lowercase);
    //pageToSkip[m][n1] = controlName1
    //pageToSkip[m][n2] = controlName2 and so on ....

    var pageToSkip = new Array(5);
    pageToSkip[0] = new Array(2);
    pageToSkip[1] = new Array(0);
    pageToSkip[2] = new Array(0);
    pageToSkip[3] = new Array(0);
    pageToSkip[4] = new Array(0);
    pageToSkip[5] = new Array(0);


    pageToSkip[0][0] = 'projectdetails.aspx';
    pageToSkip[0][1] = 'cboProjectTemplate';
    pageToSkip[0][2] = 'cboChooseType';
    pageToSkip[1][0] = 'projecthistory.aspx';
    pageToSkip[2][0] = 'deptmembers.aspx';
    pageToSkip[3][0] = 'securitygroup.aspx';
    pageToSkip[4][0] = 'busunitmembers.aspx';
    pageToSkip[5][0] = 'project_timeline.aspx';

    var sURL = location.pathname.toLowerCase();
    var quickCheck = false;

    for (var i = 0; i < pageToSkip.length; i++) {

        if (sURL.indexOf(pageToSkip[i][0]) > 0) {
            //found URL
            quickCheck = true;

            for (var j = 1; j < pageToSkip[i].length; j++) {
                if (document.forms[0].elements[pageToSkip[i][j]])
                    showHideElement(document.forms[0].elements[pageToSkip[i][j]], mLeft, mTop, mWidth, mHeight, showHide);
            }
        }
    }

    //if not using quick check, then loop thru form
    if (!quickCheck) {
        for (var i = 0; i < document.forms[0].length; i++) {
            elm = document.forms[0].elements[i];
            showHideElement(elm, mLeft, mTop, mWidth, mHeight, showHide);
        }
    }
}

function showHideElement(elm, mLeft, mTop, mWidth, mHeight, showHide) {
    var iLeft = 0;
    var iTop = 0;
    if (!elm.type || elm.type == null)
        return;
    if (elm.type.substring(0, 6) == "select") {
        var oCurrentNode = elm;
        while (oCurrentNode.tagName != "BODY") {
            iLeft += oCurrentNode.offsetLeft;
            iTop += oCurrentNode.offsetTop;
            oCurrentNode = oCurrentNode.offsetParent;
        }

        var tableTop = iTop;
        var tableLeft = iLeft;
        iTop = (parseInt(tableTop) + parseInt(elm.offsetHeight));
        iLeft = (parseInt(tableLeft) + parseInt(elm.offsetWidth));

        var shCombo = 0;


        if (
        (mLeft >= tableLeft && mLeft <= iLeft && mTop >= tableTop && mTop <= iTop) ||
        ((mLeft + mWidth) >= tableLeft && (mLeft + mWidth) <= iLeft && mTop >= tableTop && mTop <= iTop) ||
        (mLeft >= tableLeft && mLeft <= iLeft && (mTop + mHeight) >= tableTop && (mTop + mHeight) <= iTop) ||
        ((mLeft + mWidth) >= tableLeft && (mLeft + mWidth) <= iLeft && (mTop + mHeight) >= tableTop && (mTop + mHeight) <= iTop) ||
        (tableLeft >= mLeft && tableLeft <= (mLeft + mWidth) && tableTop >= mTop && tableTop <= (mTop + mHeight)) ||
        (iLeft >= mLeft && iLeft <= (mLeft + mWidth) && tableTop >= mTop && tableTop <= (mTop + mHeight)) ||
        (tableLeft >= mLeft && tableLeft <= (mLeft + mWidth) && iTop >= mTop && iTop <= (mTop + mHeight)) ||
        (iLeft >= mLeft && iLeft <= (mLeft + mWidth) && iTop >= mTop && iTop <= (mTop + mHeight)) ||
        (mLeft >= tableLeft && mLeft <= iLeft && mTop <= tableTop && (mTop + mHeight) >= iTop) ||
        (mLeft >= tableLeft && mLeft <= iLeft && mTop >= tableTop && (mTop + mHeight) <= iTop) ||
        ((mLeft + mWidth) >= tableLeft && (mLeft + mWidth) <= iLeft && mTop <= tableTop && (mTop + mHeight) >= iTop) ||
        ((mLeft + mWidth) >= tableLeft && (mLeft + mWidth) <= iLeft && mTop >= tableTop && (mTop + mHeight) <= iTop) ||
        (mTop >= tableTop && mTop <= iTop && mLeft <= tableLeft && (mLeft + mWidth) >= iLeft) ||
        (mTop >= tableTop && mTop <= iTop && mLeft >= tableLeft && (mLeft + mWidth) <= iLeft) ||
        ((mTop + mHeight) >= tableTop && (mTop + mHeight) <= iTop && mLeft <= tableLeft && (mLeft + mWidth) >= iLeft) ||
        ((mTop + mHeight) >= tableTop && (mTop + mHeight) <= iTop && mLeft >= tableLeft && (mLeft + mWidth) <= iLeft)
        )
            shCombo = 1;

        if (shCombo == 1) {
            elm.style.visibility = showHide;
        }
    }
}

// Global variables 
USETEXTLINKS = 1
indexOfEntries = new Array
nEntries = 0
doc = document
browserVersion = 0
selectedFolder = 0
var FTB_HelperFilesParameters = 'tabid=1 ';

var newWnd = null;
function menuOpenWnd(sURL, sWnd, sFeature) {
    if (newWnd != null)
        newWnd.close();
    newWnd = window.open(sURL, sWnd, sFeature);
    newWnd.focus();
    return;
}

function menuChangeImage(imgElmName, imgVarName) {
    if (!document.images[imgElmName])
        return;
    document.images[imgElmName].src = imgVarName.src;
}

function menuChangeBGImage(elmName, imgVarName) {
    if (!document.getElementById(elmName))
        return;
    if (!document.getElementById(elmName).style)
        return;

    document.getElementById(elmName).style.backgroundImage = 'url(' + imgVarName.src + ')';
}

function stringreplace(checkMe, toberep, repwith) {
    var temp = checkMe;
    var i = temp.indexOf(toberep);
    while (i > -1) {
        temp = temp.replace(toberep, repwith);
        i = temp.indexOf(toberep, i + repwith.length + 1);
    }
    return temp;
}

function CallSearch(ArticleID, ModuleID, OpenInNewWindow) {
    //NB: Note this function is duplicated in the default.js file. Any change you make to this function must also be made in that file.
    var strEval
    strEval = document.getElementById('Module' + ModuleID + '_strSearchKeyword' + ModuleID).value;

    if (isblank(strEval)) {
        alert("Please enter your keywords");
        return;
    }

    var objSearchOpRadio_0 = document.getElementById('Module' + ModuleID + '_radioSearchOption_0');
    var objSearchOpRadio_1 = document.getElementById('Module' + ModuleID + '_radioSearchOption_1');
    var objSearchOpRadio_2 = document.getElementById('Module' + ModuleID + '_radioSearchOption_2');

    if (objSearchOpRadio_2) {
        if (objSearchOpRadio_2.checked) {
            OpenInNewWindow = 1
        }
    }
    var windowStyle = "''";
    if (OpenInNewWindow == 1) {

        var objWHeight = document.getElementById('Module' + ModuleID + '_textNewWindowHeight');
        var objWWidth = document.getElementById('Module' + ModuleID + '_textNewWindowWidth');
        var objWResize = document.getElementById('Module' + ModuleID + '_textNewWindiwResize');
        var scrollBars = 0;
        windowStyle = "'toolbar=yes"; //= "'height=600,width=800,status=1,resizeable=0,scrollbars=1'";

        if (objWHeight) {
            if (IsNumber(objWHeight.value)) {
                windowStyle = windowStyle + ",height=" + objWHeight.value;
                scrollBars = 1;
            }
        }
        if (objWWidth) {
            if (IsNumber(objWWidth.value)) {
                windowStyle = windowStyle + ",width=" + objWWidth.value;
                scrollBars = 1;
            }
        }
        if (objWResize) {
            if (objWResize.value == "True") {
                windowStyle = windowStyle + ",resizable=yes";
                scrollBars = 1;
            }
            else if (objWResize.value == "False") {
                windowStyle = windowStyle + ",resizable=no";
                scrollBars = 1;
            }
        }
        if (scrollBars == 1) {
            windowStyle = windowStyle + ",scrollbars=1"
        }

    }

    if (objSearchOpRadio_2) {
        if (objSearchOpRadio_2.checked) {
            windowStyle = windowStyle + ",toolbar=1,menubar=1,titlebar=1,location=1'";
            url = "http://www.google.com.au/search?hl=en&q=" + escape(encodeMyHtml(strEval)) + "&meta=cr%3DcountryAU";
            window.open(url, '_blank', windowStyle, 'true');
            return;
        }
    }

    if (OpenInNewWindow == 1) {
        windowStyle = windowStyle + "'";
    }

    var baseObj = document.getElementById('BaseDefault');
    var baseRef;
    if (baseObj) {
        baseRef = baseObj.href.substring(0, baseObj.href.lastIndexOf("/") + 1) + 'PerformSearch.aspx';
    } else {
        var arrJSScript = document.getElementsByTagName('script');
        var jsSrc = '';
        baseRef = '';

        if (arrJSScript.length > 0) {
            for (var i = 0; i < arrJSScript.length; i++) {

                if (arrJSScript[i].getAttribute && arrJSScript[i].getAttribute('src')) {
                    jsSrc = arrJSScript[i].getAttribute('src');
                    if (jsSrc.toLowerCase().indexOf(pageName) >= 0) {
                        //N.B. default.js ALWAYS store in include/js, ../../ will neutralize the path structure
                        baseRef = jsSrc.substring(0, jsSrc.length - (pageName).length) + '../../PerformSearch.aspx';
                        break;
                    }
                }
            }
        }

        if (baseRef == '')
            baseRef = '/PerformSearch.aspx';
    }

    var SiteSectionObj = document.getElementById('Module' + ModuleID + '_selSearchSection');
    var SiteSectionValue;
    var SiteSectionDescr;
    if (SiteSectionObj && SiteSectionObj.selectedIndex >= 0) {
        SiteSectionValue = SiteSectionObj.options[SiteSectionObj.selectedIndex].value;
        SiteSectionDescr = SiteSectionObj.options[SiteSectionObj.selectedIndex].text;
    } else {
        SiteSectionValue = '';
        SiteSectionDescr = '';
    }

    if (objSearchOpRadio_0) {
        if (objSearchOpRadio_0.checked) {
            if (OpenInNewWindow == 1) {
                window.open(baseRef + "?ArticleID=" + ArticleID + "&ModuleID=" + ModuleID + "&Keywords=" + escape(encodeMyHtml(strEval)) + "&SiteSection=" + escape(encodeMyHtml(SiteSectionValue)) + "&SiteSectionDescr=" + escape(encodeMyHtml(SiteSectionDescr)) + "&multiSite=false", '_blank', windowStyle, 'true');
            }
            else {
                location.href = baseRef + "?ArticleID=" + ArticleID + "&ModuleID=" + ModuleID + "&Keywords=" + escape(encodeMyHtml(strEval)) + "&SiteSection=" + escape(encodeMyHtml(SiteSectionValue)) + "&SiteSectionDescr=" + escape(encodeMyHtml(SiteSectionDescr)) + "&multiSite=false";
            }
            return;
        }
    }

    if (objSearchOpRadio_1) {
        if (objSearchOpRadio_1.checked) {
            if (OpenInNewWindow == 1) {
                window.open(baseRef + "?ArticleID=" + ArticleID + "&ModuleID=" + ModuleID + "&Keywords=" + escape(encodeMyHtml(strEval)) + "&SiteSection=" + escape(encodeMyHtml(SiteSectionValue)) + "&SiteSectionDescr=" + escape(encodeMyHtml(SiteSectionDescr)) + "&multiSite=true", '_blank', windowStyle, 'true');
            }
            else {
                location.href = baseRef + "?ArticleID=" + ArticleID + "&ModuleID=" + ModuleID + "&Keywords=" + escape(encodeMyHtml(strEval)) + "&SiteSection=" + escape(encodeMyHtml(SiteSectionValue)) + "&SiteSectionDescr=" + escape(encodeMyHtml(SiteSectionDescr)) + "&multiSite=true";
            }
            return;
        }
    }

    if (OpenInNewWindow == 1) {
        window.open(baseRef + "?ArticleID=" + ArticleID + "&ModuleID=" + ModuleID + "&Keywords=" + escape(encodeMyHtml(strEval)) + "&SiteSection=" + escape(encodeMyHtml(SiteSectionValue)) + "&SiteSectionDescr=" + escape(encodeMyHtml(SiteSectionDescr)), '_blank', windowStyle, 'true');
    }
    else {
        location.href = baseRef + "?ArticleID=" + ArticleID + "&ModuleID=" + ModuleID + "&Keywords=" + escape(encodeMyHtml(strEval)) + "&SiteSection=" + escape(encodeMyHtml(SiteSectionValue)) + "&SiteSectionDescr=" + escape(encodeMyHtml(SiteSectionDescr));
    }

}

function HandleSearch(evt, ArticleID, ModuleID, OpenInNewWindow) {
    //NB: Note this function is duplicated in the default.js file. Any change you make to this function must also be made in that file.
    if (evt.keyCode == 13) {
        CallSearch(ArticleID, ModuleID, OpenInNewWindow)
        if (!document.all && document.getElementById) {
            evt.preventDefault();
            evt.stopPropagation();
        }
        evt.cancelBubble = true;
        evt.returnValue = false;
        return false;
    }
}

function trim(sString) {
    while (sString.substring(0, 1) == ' ') {
        sString = sString.substring(1, sString.length);
    }
    while (sString.substring(sString.length - 1, sString.length) == ' ') {
        sString = sString.substring(0, sString.length - 1);
    }
    return sString;
}

var XmlHttpRequestInstance = false;
var XmlHttpRequestResponseHandlerFunction = "";
var jsGlobalArticleListControl = ""; /* Article List control Global variable */

function SendXMLHttpRequest(URL, ResponseHandlerFunction) {

    var loadingDiv = null;
    loadingDiv = document.getElementById('loadingDiv');
    if (loadingDiv != null) {
        loadingDiv.innerHTML = "<img src='/images/spinner.gif' alt='loading..please wait' /><label> loading... please wait</label>"; //loading            
    }

    XmlHttpRequestResponseHandlerFunction = ResponseHandlerFunction;
    try {
        this.XmlHttpRequestInstance = new ActiveXObject("Msxml2.XMLHTTP");
    }
    catch (e) {
        try {
            XmlHttpRequestInstance = new ActiveXObject("Microsoft.XMLHTTP");
        }
        catch (E) {
            XmlHttpRequestInstance = false;
        }
    }
    if (!XmlHttpRequestInstance && typeof XMLHttpRequest != 'undefined') {
        XmlHttpRequestInstance = new XMLHttpRequest();
    }
    if (!XmlHttpRequestInstance && window.createRequest) {
        try {
            XmlHttpRequestInstance = window.createRequest();
        }
        catch (e) {
            XmlHttpRequestInstance = false;
        }
    }
    if (XmlHttpRequestInstance) {
        XmlHttpRequestInstance.open("GET", URL, true);
        XmlHttpRequestInstance.onreadystatechange = ReceiveXMLHttpResponse;
        XmlHttpRequestInstance.send(null);
    }
    else {
        alert("Cannot Initiate HTTP Request.");
    }
}

function ReceiveXMLHttpResponse(ResponseHandlerFunction) {
    if (XmlHttpRequestInstance.readyState == 4) {
        if (XmlHttpRequestInstance.status == 200) {
            eval(XmlHttpRequestResponseHandlerFunction + "('" + XmlHttpRequestInstance.responseText + "')");
            setTimeout(loadingComplete, 2000);
        }
        else {
            alert("Bad HTTP Request");
        }
    }
}

function loadingComplete() {
    var loadingDiv = null;
    loadingDiv = document.getElementById('loadingDiv');

    if (loadingDiv != null)
        loadingDiv.innerHTML = '';
}

/* 
Selected index change of the folderlist control should call this function with params selectedfolder and articlelistcontrolname to refresh the article list for the associated
folder by passing the type querystring which would call the appropriate server side function */
function AjaxRequest(selectedFolderID, articleListControl) {
    var ajaxResponsePageName = GetRoot() + "AjaxRequest.aspx";    /* Page to call */
    jsGlobalArticleListControl = articleListControl; /* Set Global var to control name */
    SendXMLHttpRequest(ajaxResponsePageName + "?Type=ArticlesForFolder&FolderID=" + eval(selectedFolderID), 'AjaxPopulateArticleList');
}

function AjaxPopulateArticleList(ResponseString) {
    var ArticleArray = new Array();
    var count;
    var i = 0;
    var j = 1;
    var objSel = document.getElementById(jsGlobalArticleListControl); /* global declaration which gets assigned with the control name in the AjaxRequest function */
    objSel.options.length = 0;
    ArticleArray = ResponseString.split("||||");
    count = ArticleArray.length;
    objSel.options[0] = new Option("(none)", "0", false, false);
    while (i < count) {
        if (ArticleArray[i] != null) {
            if (ArticleArray[i].toString().length > 0) {
                name = ArticleArray[i].toString().split("|||")[0].toString();
                value = ArticleArray[i].toString().split("|||")[1].toString();
                objSel.options[j] = new Option(name, value, false, false);
                j = j + 1;
            }
        }
        i = i + 1;
    }
}

function OpenWindow(aURL) {
    var left, top, width, height;

    if (aURL != "") {
        if (screen.width > 800) {
            left = 205;
            top = 186;
            width = 810;
            height = 475;
        }
        else {
            left = 205;
            top = 185;
            width = 582;
            height = 312;
        }
        if (aURL.toLowerCase().indexOf('.aspx') > -1) {
            if (aURL.indexOf('?') > -1) {
                aURL = aURL + '&' + 'Embed=Y';
            }
            else {
                aURL = aURL + '?' + 'Embed=Y';
            }
        }

        window.open(aURL, '', 'menubar=yes, scrollbars=yes, status=no, titlebar=yes, toolbar=no, resizable=yes, left=' + left + ', top=' + top + ', width=' + width + ', height=' + height);
    }
}

function assignImgSubmitButton(imgPath) {
    if (imgPath.length == 0)
        return;
    if (sCtrlID == null || sCtrlID == '') {
        alert('Missing control ID, please try again!');
        return;
    }

    if (!document.getElementById(sCtrlID + 'imgSubmitButton')) return;
    //assign img & hidden variable
    document.getElementById(sCtrlID + 'imgSubmitButton').src = imgPath;
    document.getElementById(sCtrlID + 'hidSubmitButtonImage').value = imgPath;
    self.focus();

}

function GetElementByClientId(ID) {
    return document.getElementById(GetClientId(ID));
}

function GetClientId(ID) {
    var prefix;

    var newID;

    newID = ID;
    if (document.getElementById(newID) != null) return newID;

    //prefix = "ctl00";
    //newID = prefix + "_" + ID;
    //if (document.getElementById(newID) != null) return newID;

    prefix = "ctl00_ContentPlaceHolderMain";
    newID = prefix + "_" + ID;
    if (document.getElementById(newID) != null) return newID;


    prefix = "ctl00_ContentPlaceHolderMainNoAjax";
    newID = prefix + "_" + ID;
    if (document.getElementById(newID) != null) return newID;

}

function GetRoot() {
    //Scenarios:
    //http://intranet [works]
    //http://www.elcom.com.au [works]

    var siteUrl = window.location.protocol + '//' + window.location.host + '/'

    return siteUrl;

    // this does not handle subsites.  (moving away from subsites for implementation)
    //http://localhost/cmdotnet [DOES NOT work]
}

function CopyURLToClipboard(clipText, alternateText) {
    if (navigator.appName == "Microsoft Internet Explorer" && navigator.appVersion >= "4.0") {
        Copied = clipText.createTextRange();
        Copied.execCommand("RemoveFormat");
        Copied.execCommand("Copy");
        alert('User Friendly URL copied to Clipboard');
    }
    else {
        alert('Your browser security does not support clipboard access: Here is your url \n' + alternateText);
    }
}

//get value from query string
function getQueryVariable(variable) {
    var query = window.location.search.substring(1);
    var vars = query.split("&");
    for (var i = 0; i < vars.length; i++) {
        var pair = vars[i].split("=");
        if (pair[0].toLowerCase() == variable.toLowerCase()) {
            return pair[1];
        }
    }
}

function confirmDelete() {
    var agree = confirm("Are you sure you wish to delete this record?");
    if (agree)
        return true;
    else
        return false;
}

function ClearTextSelection() {
    var sel = window.getSelection ? window.getSelection() : document.selection;
    if (sel) {
        if (sel.removeAllRanges) {
            sel.removeAllRanges();
        }
        else if (sel.empty) {
            sel.empty();
        }
    }
}

if (typeof jQuery == 'undefined') {
}
else {
    $(function () {
        if ($('.edit-buttons .admin-pill').length > 0) {
            if ($('#AdminMenu').length > 0) {
                $('.edit-buttons:first').addClass('admin-menu-on');
            }
        }
        else {
            if ($('#AdminMenu').length > 0) {
                $('#AdminMenu').before('<div class="edit-buttons view-page pg1 admin-menu-on"><div class="logos"><a href="/" title="Go to Homepage" class="hex">Home</a><a href="/adminhomepage.aspx" title="Go to Dashboard" class="elcomlogo">Home</a></div><div class="admin-pill standalone"><div class="inner"><a title="Go to Dashboard" href="/adminhomepage.aspx" class="dashboard-button">Dashboard</a></div></div></div>');
            }
        }
    });
}

function MakeValidUrlSegmentForArticle(text) {
    // Create a valid url segment from a document name by replacing characters that should not appear within a url.
    // Note: This logic should be replicated in the procedure procGetNameForCopiedArticleOrFolder
    // NOTE: this function DOES NOT replace / as it is valid for article urls

    var urlSegment = text.trim();

    //remove ' 
    urlSegment = urlSegment.replace(/'/gi, "");

    // replace characters which are NOT: alphanumeric, - _
    urlSegment = urlSegment.replace(/[^\w-_\/]/gi, "-");

    // remove double ups and triple up - 
    urlSegment = urlSegment.replace(/\-+/g, "-");

    // remove leading and trailing -
    urlSegment = urlSegment.replace(/-$/g, "");
    urlSegment = urlSegment.replace(/^-/g, "");

    // convert to lower case
    return urlSegment.toLowerCase();
}

function MakeValidUrlSegment(text) {
    // Create a valid url segment from a document name by replacing characters that should not appear within a url.
    // Note: This logic should be replicated in the procedure procGetNameForCopiedArticleOrFolder
    // NOTE: this function REPLACES / as it is not valid in other urls eg. folder, social q and a
    var urlSegment = text.trim();

    // remove '
    urlSegment = urlSegment.replace(/'/gi, "");

    // replace characters which are NOT: alphanumeric, / - _
    urlSegment = urlSegment.replace(/[^\w-_]/gi, "-");

    // remove double ups and triple up - 
    urlSegment = urlSegment.replace(/\-+/g, "-");

    // remove leading and trailing -
    urlSegment = urlSegment.replace(/-$/g, "");
    urlSegment = urlSegment.replace(/^-/g, "");

    // convert to lower case
    return urlSegment.toLowerCase();
}

function getInternetExplorerVersion() {
    var rv = -1;
    if (navigator.appName == 'Microsoft Internet Explorer') {
        var ua = navigator.userAgent;
        var re = new RegExp("MSIE ([0-9]{1,}[\.0-9]{0,})");
        if (re.exec(ua) != null)
            rv = parseFloat(RegExp.$1);
    }
    else if (navigator.appName == 'Netscape') {
        var ua = navigator.userAgent;
        var re = new RegExp("Trident/.*rv:([0-9]{1,}[\.0-9]{0,})");
        if (re.exec(ua) != null)
            rv = parseFloat(RegExp.$1);
    }
    return rv;
}

$(document).ready(function () {
    if (document.getElementById("AdminMenu")) {
        $('#main-menu-toggle').click(function (e) {
            e.preventDefault();
            $('#AdminBar').toggle();
        });
    }
});

// Provide selector for a container element that contains the tabs - this way multiple tabbed sections can be configured per page. Should correctly handle nested tabs also
function configureTabs(container) {
    // Setup the roles and accessibility options if they are not present on the elements
    containerEl = $(container);

    var tabs = containerEl.find("ul.tabs").first(); // important to grab only first - we do not want to grab any tabs nested in the panels
    tabs.attr("role", "tablist");

    tabs.find("li").each(function (i) {
        var tab = $(this);
        var tabLink = tab.find("a");
        var tabPanelId = tabLink.attr("href").replace("#", "");
        var tabLinkId = tabLink.attr("id") || "tabtitle" + i;
        var tabPanel = $("#" + tabPanelId);
        // Handle ASP.NET auto IDs on panels - it will cause the href not to match, so we address this here...
        if (tabPanel.length < 1) {
            tabPanel = containerEl.find("[id$='" + tabPanelId + "']");
            tabPanelId = tabPanel[0].id;
            if (tabPanel.length > 0) tabLink.attr("href", "#" + tabPanel[0].id);
        }

        tab.attr("role", "tab")
            .attr("aria-controls", tabPanelId)
            .attr("aria-labelledby", tabLinkId);

        tabLink.attr("role", "presentation")
            .attr("id", tabLinkId);

        if (i == 0) {
            tab.attr("aria-selected", "true");
            tabLink.addClass("selected");
            tabPanel.attr("aria-expanded", "true")
                .attr("aria-hidden", "false");

            if (!/Currently showing/i.test(tabLink.text())) {
                tabLink.append('<span class="sr-only"> - Currently showing</span>');
            }
        } else {
            tab.attr("aria-selected", "false");
            tabLink.removeClass("selected")
            tabPanel.attr("aria-expanded", "false")
                .attr("aria-hidden", "true")
                .css("display", "none");

            if (!/Show below/i.test(tabLink.text())) {
                tabLink.append('<span class="sr-only"> - Show below</span>');
            }
        }

        tabPanel.attr("role", "tabpanel")
            .attr("aria-labelledby", tabLinkId)
            .addClass("tab_content");
    });

    //On Click Event
    tabs.find("li a").click(function (e) {
        e.preventDefault();
        return tabClicked($(this));
    });

    // Custom event added to container to change the tab... can be invoked with xxx.on("setActiveTab", "#tabId")
    containerEl.on('setActiveTab', function (e, tabName) {
        var container = $(this);
        var tab = container.find("[href='" + tabName + "']");
        var tabPanel = tab.closest("[role='tablist']");
        tabClicked(tab);
    });

    // call when a tab is clicked, pass the tab element (the <li>) that has been clicked
    function tabClicked(tab) {
        var tabPanel = tab.closest("[role='tablist']");
        tabPanel.find("li[aria-selected='true']")
            .attr("aria-selected", "false")
            .find("a.selected")
            .removeClass("selected")
            .find("span.sr-only")
            .text(" - Show below");

        tab.addClass("selected")
            .parent()
            .attr("aria-selected", "true")
            .find("span.sr-only")
            .text(" - Currently showing");

        tabPanel.find("a").each(function (e) {
            var panelId = $(this).attr("href");
            $(panelId).hide().attr("aria-expanded", "false").attr("aria-hidden", "true");
        });

        var activeTab = tab.attr("href");

        if (activeTab) {
            $(activeTab).show().attr("aria-expanded", "true").attr("aria-hidden", "false");
        }
        return false;
    }
}

// create show/hide button/checkbox toggles
function setupSectionToggles() {
    $("[data-togglectrl]").each(function () {
        var toggleDiv = $(this);
        var cbID = toggleDiv.data("togglectrl");
        var cb = $(cbID);
        setVis(cb, toggleDiv);
        cb.change(toggleDiv, function (e) {
            setVis($(this), e.data);
        });

        function setVis(src, dst) {
            if (src.prop("checked")) dst.show();
            else dst.hide();
        }
    });
}

/* end of common.js */