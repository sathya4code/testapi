﻿/* start of donutloading.js */
function DonutLoad(targetElementCss, serviceURL, getOrPost,data) {
   var resultData;   
   if($('.' + targetElementCss).length) {
       $.ajax({
           cache: false,
           url: serviceURL,
           type: getOrPost,
           async: false,
           dataType: "json",
           data: data,
           contentType: "application/json; charset=utf-8",
           success: function (result) {
               if (result && result.d && result.d.IsSuccessful) {
                   var data = result.d.Data;
                   resultData = data;

                   var targetDiv = $('.' + targetElementCss);
                   targetDiv.each(function (i) { $(this).html(resultData); });                   
               }
               else {
                   errors.showError('An error occured while contacting the server. - 2');
               }
           },
           error: function (msg) {
               errors.showError(msg);
           }
       });
    }

}

/* end of donutloading.js */
