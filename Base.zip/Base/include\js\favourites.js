﻿/* start of favourites.js */
var Favourite = {

    getAllFavouritesPath: { url: '/WebServices/FavouritesService.asmx/list', type: 'POST' },
    addFavouritePath: { url: '/WebServices/FavouritesService.asmx/add', type: 'POST' },
    deleteFavouritePath: { url: '/WebServices/FavouritesService.asmx/delete', type: 'POST' },

    // favourites list element
    loadFavouriteGrid: function (param1) {

        var maxItemCount = 0;
        if ($("#hdnFavouriteListInitialCnt").length > 0) {
            maxItemCount = $("#hdnFavouriteListInitialCnt").val();
        }
        Favourite.reloadFavouriteMenuList();
        var reqData = { 'maxItemCount': maxItemCount };
        var url = Favourite.getAllFavouritesPath.url;

        try {
            Favourite.ajaxExecute(url, Favourite.getAllFavouritesPath.type, reqData, Favourite.onFavouritesGetSuccessBuildGrid, true, param1);
        } catch (e) {
            console.warn(e.Message);
        }


    },

    onFavouritesGetSuccessBuildGrid: function (rslt) {
        var items = rslt.d.Data;

        if (items) {
            if (items && items.length > 0) {
                var item;
                var totalCount=0;
                var fav = '<ul class="no-list">';
                for (var i = 0; i < items.length; i++) {
                    item = items[i];
                    totalCount = item.TotalCount;
                    fav += '<li class="padding-bottom" data-fav-id="' + item.numFavouriteID + '" data-fav-url="' + item.PageURL + '">';

                    if (item.active === false) {
                        fav += '<span title="This favourite is no longer available" class="icon icon-left icon-tiny icon-error text-warning">' + item.PageTitle + '<span class="sr-only"> (this favourite is no longer available)</span></span>';
                    }
                    else {
                        fav += '<a href="' + item.PageURL + '">' + item.PageTitle;
                        if (item.PageURL.toLowerCase().indexOf('folders.aspx') > 0) {
                            fav += '<span class="icon icon-only icon-tiny icon-admin" title="This favourite links to an admin page"><span class="sr-only"> (this favourite links to an admin page)</span></span>';
                        }
                        fav += '</a>';
                        //fav += Favourite.getDescriptionColumn(item.PageTitle, item.PageURL);
                    }
                    fav += Favourite.getActionColumn(item.numFavouriteID);
                    fav += '</li>';
                }
                fav += '</ul>';
                if (items.length < totalCount) {
                    fav += '<p class="my-fav-more"><button type="button" class="btn btn-secondary" aria-label="Show more favourites" onclick="Favourite.showMoreFavourites()">Show more</button></p>';
                }
                $('#divMyFavourites').html(fav);
            }
            else {
                $('#divMyFavourites').html('<p class="my-fav-none">No favourites added</p>');
            }
        }
    },

    getDescriptionColumn: function (pageName, pageURL) {
        return '<a href="' + pageURL + '">' + pageName + '</a>';
    },

    getActionColumn: function (favID) {
        return '<button type="button" title="Remove from favourites" aria-label="Remove this page from favourites" class="margin-left btn btn-link icon icon-left icon-tiny icon-only icon-cross text-danger" data-action-id="' + favID + '" onclick="Favourite.deleteFavourite(' + favID + ')">Remove from favourites</button>';
    },

    deleteFavourite: function (favID) {
        var reqData = { 'id': favID };
        var url = Favourite.deleteFavouritePath.url;
        Favourite.ajaxExecute(url, Favourite.deleteFavouritePath.type, reqData, Favourite.loadFavouriteGrid, true, "");
    },

    showMoreFavourites: function () {
        if ($("#hdnFavouriteListInitialCnt").length > 0) {
            var cnt = $("#hdnFavouriteListInitialCnt").val();
            maxItemCount = parseInt(cnt);
            if (maxItemCount > 0) {
                maxItemCount += 10;
            } else {
                maxItemCount = 10;
            }
            $("#hdnFavouriteListInitialCnt").val(maxItemCount);// Fix for Show more not working...
            Favourite.loadFavouriteGrid();
        }
    },

    // used for <~~displayfavourites~~>

    LoadFavouriteNotifications: function (rslt) {
        data = rslt.d.Data;
        $('.divMyFavourites ul.my-fav-list').remove();
        $('.divMyFavourites .my-fav-more').remove();
        $('.divMyFavourites .my-fav-none').remove();
        var redirectUrl = '/notifications/favourites-list';

        // check if variable customUrl is defined (in code block)
        if (typeof customUrl !== 'undefined') {
            redirectUrl = customUrl;
        }

        if (!redirectUrl.startsWith('/')) {
            redirectUrl = '/' + redirectUrl;
        }

        var content = "";
        if (data && data.length > 0) {
            content = '<ul class="my-fav-list">';
            $.each(data, function (i, val) {
                content += '<li class="padding-bottom">';
                if (val.active === false) {
                    content += '<span title="This favourite is no longer available" class="icon icon-left icon-tiny icon-error text-warning py-0">' + val.PageTitle + '<span class="sr-only"> (this favourite is no longer available)</span></span>';
                }
                else {
                    content += '<a href="' + val.PageURL + '">' + val.PageTitle;
                    if (val.PageURL.toLowerCase().indexOf('folders.aspx') > 0) {
                        content += '<span class="icon icon-only icon-tiny icon-admin py-0" title="This favourite links to an admin page"><span class="sr-only"> (this favourite links to an admin page)</span></span>';
                    }
                    content += '</a>';
                }
                content += '</li>';
            });
            content += '</ul><p class="my-fav-more"><a class="btn btn-link" href="' + redirectUrl + '">See all</a></p>';
        }
        else {
            content = '<p class="my-fav-none">No favourites added</p>';
        }
        if ($(".divMyFavourites ul li a.icon-nav-fav") && $(".divMyFavourites ul li a.icon-nav-fav").length > 0) {
            $(".divMyFavourites ul li a.icon-nav-fav").after(content);
        }
        else {
            $('.divMyFavourites').append(content);
        }
    },

    // used for <~~addfavourites~~>

    loadFavouriteActionBtn: function (action, itemID, itemType, favID) {
        var divFavBtns = "";
        var favText = "";
        var favType = "";
        var favClass = "";
        if (action === "R") {
            favText = "Remove from favourites";
            favType = "R";
            favClass = " icon-solid";
        }
        else {
            favText = "Add to favourites";
            favType = "A";
            favClass = "";
        }
        divFavBtns = '<button type="button" id="addRemoveEcfavbtn" title="' + favText + '" data-type-param="' + favType + '" data-article-id="' + itemID + '" data-item-type-id="' + itemType + '" data-fav-id="' + favID + '" onclick="Favourite.addOrRemoveFavourite(this)" class="btn btn-link icon icon-small icon-only icon-dark icon-fav' + favClass + '" aria-label="' + favText + '">' + favText + '</button>';
        $(".spanAddRemoveEcFavourite").html(divFavBtns);
    },

    addOrRemoveFavourite: function (ctrl) {
        var paramType = $(ctrl).attr("data-type-param");
        var articleID = $(ctrl).attr("data-article-id");
        var ItemTypeID = $(ctrl).attr("data-item-type-id");
        var favID = $(ctrl).attr("data-fav-id");
        if (paramType === "A") {
            Favourite.addPageToFavourite(articleID, ItemTypeID, $(ctrl));
        }
        else {
            Favourite.removePageFromFavourite(favID, $(ctrl));
        }

        //Reload the favourites menu list when any fav is added or removed...
        Favourite.reloadFavouriteMenuList();
    },

    reloadFavouriteMenuList: function () {

        var maxItemCount = 10;
        var loadAll = false;
        var reqData = { 'maxItemCount': maxItemCount, 'loadAll': loadAll };
        var url = Favourite.getAllFavouritesPath.url;
        Favourite.ajaxExecute(url, Favourite.getAllFavouritesPath.type, reqData, Favourite.LoadFavouriteNotifications, true, "");
    },

    addPageToFavourite: function (articleID, ItemTypeID, ctrl) {
        var reqData = { 'ItemID': articleID, 'ItemTypeID': ItemTypeID, 'PageURL': window.location.href, 'PageTitle': document.title };
        var url = Favourite.addFavouritePath.url;
        Favourite.ajaxExecute(url, Favourite.addFavouritePath.type, reqData, Favourite.onFavouritesAddSuccess, true, ctrl);
    },

    removePageFromFavourite: function (articleID, ctrl) {
        var reqData = { 'id': articleID };
        var url = Favourite.deleteFavouritePath.url;
        Favourite.ajaxExecute(url, Favourite.deleteFavouritePath.type, reqData, Favourite.onFavouritesRemoveSuccess, true, ctrl);
    },

    onFavouritesAddSuccess: function (favID, btn) {
        btn.attr("data-fav-id", favID.d);
        btn.attr("data-type-param", 'R');
        btn.addClass("icon-solid");
        btn.prop('title', 'Remove from favourites');
        btn.text('Remove from favourites');
    },

    onFavouritesRemoveSuccess: function (favID, btn) {
        btn.attr("data-type-param", 'A');
        btn.removeClass("icon-solid");
        btn.prop('title', 'Add page to favourites');
        btn.text('Add page to favourites');
    },

    //Ajax Call
    ajaxExecute: function (url, type, reqData, successCallback, isAsync, param1) {
        if (typeof isAsync === typeof undefined) {
            isAsync = true;
        }
        reqData = reqData === null ? null : JSON.stringify(reqData);
        Favourite.showLoadingMsg();
        $.ajax({
            type: type,
            url: url,
            dataType: 'json',
            data: reqData,
            contentType: 'application/json; charset=utf-8',
            cache: false,
            async: isAsync,
            success: function (resp) {
                if (param1) { successCallback(resp, param1); } else { successCallback(resp); }
                Favourite.hideLoadingMsg();
            },
            error: function (xhr, desc, e) {
                Favourite.hideLoadingMsg();
                if (xhr) {
                    if (xhr.responseText) {
                        if (xhr.responseText.length > 0) {
                            try {
                                var errorMsg = $.parseJSON(xhr.responseText);
                                if (errorMsg.Message) {
                                    Favourite.displayErrorMsg("page", "error", errorMsg.Message);
                                }
                            } catch (e) {
                                Favourite.displayErrorMsg("page", "error", xhr.responseText);
                            }
                        }
                    }
                }
            }
        });
    },

    showLoadingMsg: function () {
        if ($("#divLoadingMsg")) {
            $("#divLoadingMsg").show();
        }
    },

    hideLoadingMsg: function () {
        if ($("#divLoadingMsg")) {
            $("#divLoadingMsg").hide();
        }
    },

    displayErrorMsg: function (msgIn, msgType, msg) {
        if (msgIn === "page") {
            msgPH = $("#divNotificationStatusMsg");
        }
        else {
            msgPH = $("#divNotificationStatusMsg");
        }

        if (msgPH) {
            $(msgPH).removeAttr("class");
            if (msgType === "success") {
                $(msgPH).attr("class", "alert alert-success");
            }
            else if (msgType === "error") {
                $(msgPH).attr("class", "alert alert-danger");
            }
            else {
                $(msgPH).attr("class", "alert alert-info");
            }
            $(msgPH).html(msg);
            $(msgPH).show();
        }
    }

};

/* end of favourites.js */
