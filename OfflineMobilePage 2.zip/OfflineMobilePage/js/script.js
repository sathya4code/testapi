function myButtonClick() {
 alert('Button clicked');
}